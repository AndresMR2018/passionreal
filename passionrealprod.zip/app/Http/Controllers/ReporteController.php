<?php

namespace App\Http\Controllers;

use App\Models\Reporte;
use App\Http\Requests\StoreReporteRequest;
use App\Http\Requests\UpdateReporteRequest;

class ReporteController extends Controller
{
   
    public function index()
    {
        
    }

  
    public function create()
    {
        //
    }

  
    public function store(StoreReporteRequest $request)
    {
        //
    }

  
    public function show(Reporte $reporte)
    {
        //
    }

    public function edit(Reporte $reporte)
    {
        //
    }

  
    public function update(UpdateReporteRequest $request, Reporte $reporte)
    {
        //
    }


    public function destroy(Reporte $reporte)
    {
        //
    }
}
