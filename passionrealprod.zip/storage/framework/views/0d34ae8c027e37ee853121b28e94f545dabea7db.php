<div class="page-header-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="header-page">
                    <h1><?php echo e($titulo); ?></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\passionrealprod\resources\views/components/banner1280x330.blade.php ENDPATH**/ ?>