<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <!--[if IE]>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <![endif]-->
    <meta name="description" content="">
    <meta name="author" content="ScriptsBundle">
    <title>Pasionreal</title>
    <!-- =-=-=-=-=-=-= Favicons Icon =-=-=-=-=-=-= -->
    <link rel="icon" href="images/logo/logoPassionReal.jpeg" type="image/x-icon" />
    <!-- =-=-=-=-=-=-= Mobile Specific =-=-=-=-=-=-= -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- =-=-=-=-=-=-= Bootstrap CSS Style =-=-=-=-=-=-= -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- =-=-=-=-=-=-= Template CSS Style =-=-=-=-=-=-= -->
    <link rel="stylesheet" href="css/style.css">
    <!-- =-=-=-=-=-=-= Font Awesome =-=-=-=-=-=-= -->
    <link rel="stylesheet" href="css/font-awesome.css" type="text/css">
    <!-- =-=-=-=-=-=-= Flat Icon =-=-=-=-=-=-= -->
    <link href="css/flaticon.css" rel="stylesheet">
    <!-- =-=-=-=-=-=-= Et Line Fonts =-=-=-=-=-=-= -->
    <link rel="stylesheet" href="css/et-line-fonts.css" type="text/css">
    <!-- =-=-=-=-=-=-= Menu Drop Down =-=-=-=-=-=-= -->
    <link rel="stylesheet" href="css/forest-menu.css" type="text/css">
    <!-- =-=-=-=-=-=-= Animation =-=-=-=-=-=-= -->
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">
    <!-- =-=-=-=-=-=-= Select Options =-=-=-=-=-=-= -->
    <link href="css/select2.min.css" rel="stylesheet" />
    <!-- =-=-=-=-=-=-= noUiSlider =-=-=-=-=-=-= -->
    <link href="css/nouislider.min.css" rel="stylesheet">
    <!-- =-=-=-=-=-=-= Listing Slider =-=-=-=-=-=-= -->
    <link href="css/slider.css" rel="stylesheet">
    <!-- =-=-=-=-=-=-= Owl carousel =-=-=-=-=-=-= -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.css">
    <!-- =-=-=-=-=-=-= Check boxes =-=-=-=-=-=-= -->
    <link href="skins/minimal/minimal.css" rel="stylesheet">
    <!-- =-=-=-=-=-=-= Responsive Media =-=-=-=-=-=-= -->
    <link href="css/responsive-media.css" rel="stylesheet">
    <!-- =-=-=-=-=-=-= Template Color =-=-=-=-=-=-= -->
    <link rel="stylesheet" id="color" href="css/colors/defualt.css">
    <!-- =-=-=-=-=-=-= For Style Switcher =-=-=-=-=-=-= -->
    <link rel="stylesheet" id="theme-color" type="text/css" href="#" />
    <!-- =-=-=-=-=-=-= Check boxes =-=-=-=-=-=-= -->
    <link href="skins/minimal/minimal.css" rel="stylesheet">
    <!-- JavaScripts -->
    <script src="js/modernizr.js"></script>
    <script src="https://kit.fontawesome.com/a022389a13.js" crossorigin="anonymous"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
</head>

<body>
    <!-- =-=-=-=-=-=-= Preloader =-=-=-=-=-=-= -->
   
    <!-- =-=-=-=-=-=-= Color Switcher =-=-=-=-=-=-= -->
    
    <!-- =-=-=-=-=-=-= Light Header =-=-=-=-=-=-= -->
  <?php echo $__env->make('templates.header2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navigation Menu End -->
    <!-- =-=-=-=-=-=-= Light Header End  =-=-=-=-=-=-= -->
    <!-- Small Breadcrumb -->
    <div class="small-breadcrumb">
        <div class="container">
            <div class=" breadcrumb-link">
                <ul>
                    <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                    <li><a href="<?php echo e(route('cliente.miCuenta')); ?>">Mi perfil</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Small Breadcrumb -->
    <!-- =-=-=-=-=-=-= Main Content Area =-=-=-=-=-=-= -->
    <div class="main-content-area clearfix">
        <!-- =-=-=-=-=-=-= Latest Ads =-=-=-=-=-=-= -->
        <section class="section-padding gray">
            <!-- Main Container -->
            <div class="container">
                <!-- Row -->
                <div class="row">
                    <!-- Middle Content Area -->
                    <div class="col-md-4 col-sm-12 col-xs-12 leftbar-stick blog-sidebar">
                        <!-- Sidebar Widgets -->
                        <div class="user-profile">
                            <a>
                                <?php if(!($perfil->foto)): ?>
                                <img src="<?php echo e(asset('images/user_default.png')); ?>" alt="foto">
                                <?php else: ?>
                                <img src="<?php echo e(asset('storage/'.$perfil->foto)); ?>" alt="foto">
                                <?php endif; ?>
                            </a>
                            <div class="profile-detail">
                                <h6><?php echo e($user->name); ?></h6>
                                <ul class="contact-details">
                                    <li>
                                        <i class="fa fa-map-marker"></i> Ubicacion, agregar este campo en perfil 
                                    </li>
                                    <li>
                                        <i class="fa fa-envelope"></i><?php echo e($user->email); ?>

                                    </li>
                                    <li>
                                        <i class="fa fa-phone"></i><?php echo e($perfil->telefono); ?>

                                    </li>
                                    <li>
                                        <i class="fas fa-coins"></i><?php echo e($perfil->creditos); ?> créditos
                                    </li>
                                </ul>
                            </div>
                            <ul>
                                <li class="active"><a href="">Perfil</a></li>
                               
                               
                                <li><a href="<?php echo e(route('cliente.misAnuncios')); ?>">Mis anuncios</a></li>
                               
                                <li><a href="<?php echo e(route('logout')); ?>">Cerrar sesión</a></li>
                            </ul>
                        </div>
                        <!-- Categories -->
                        
                    </div>
                    <div class="col-md-8 col-sm-12 col-xs-12">
                        <!-- Row -->
                        <?php if(Session::has('mensaje')): ?>
                        <div class="alert alert-success alert-dismissible" role="alert">
                            <?php echo e(Session::get('mensaje')); ?>

                            <button type="button" class="close" data-dismiss="alert" role="alert">
                                <span aria-button="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('advertencia')): ?>
                        <div class="alert alert-warning alert-dismissible" role="alert">
                            <?php echo e(Session::get('advertencia')); ?>

                            <button type="button" class="close" data-dismiss="alert" role="alert">
                                <span aria-button="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
    
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger" role="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($error); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <div class="profile-section margin-bottom-20">
                            <div class="profile-tabs">
                                <ul class="nav nav-justified nav-tabs">
                                    <li class="active"><a href="#profile" data-toggle="tab">Perfil</a></li>
                                    <li><a href="#edit" data-toggle="tab">Editar perfil</a></li>
                                    
                                  
                                </ul>
                                <div class="tab-content">
                                    <div class="profile-edit tab-pane fade in active" id="profile">
                                        <h2 class="heading-md">Administre sus datos.</h2>
                                        <p>A continuación se muestran el nombre y las direcciones de correo electrónico registradas para su cuenta.</p>
                                        <dl class="dl-horizontal">
                                            <dt><strong>Su nombre </strong></dt>
                                            <dd>
                                               <?php echo e($perfil->nombre); ?>

                                            </dd>
                                            <dt><strong>Dirección de correo </strong></dt>
                                            <dd>
                                              <?php echo e($user->email); ?>

                                            </dd>
                                            <dt><strong>Número de teléfono </strong></dt>
                                            <dd>
                                          <?php echo e($perfil->telefono); ?>

                                            </dd>
                                            
                                            
                                            <a href="<?php echo e(route('home.getValidarCuenta')); ?>">
                                                <dt><strong>Usuario verificado: </strong></dt>
                                            </a>
                                            
                                            <dd>
                                                 <?php echo e($user->cta_validada); ?>

                                            </dd>
                                            
                                        </dl>
                                    </div>
                                    <div class="profile-edit tab-pane fade" id="edit">
                                        <h2 class="heading-md">Administra tu configuración de seguridad</h2>
                                        <p>Gestiona tu cuenta</p>
                                        <div class="clearfix"></div>
                                        <form method="POST" action="<?php echo e(route('cliente.editarMiPerfil')); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6 col-xs-12">
                                                    <label>Tu nombre completo <span class="color-red">*</span> </label>
                                                    <input name="nombre" type="text" class="form-control margin-bottom-20">
                                                </div>
                                               
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label>Número de contacto <span class="color-red">*</span></label>
                                                    <input name="telefono" type="text" class="form-control margin-bottom-20">
                                                </div>
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label>DNI <span class="color-red">*</span></label>
                                                    <input name="dni" type="text" class="form-control margin-bottom-20">
                                                </div>
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label>Foto <span class="color-red">*</span></label>
                                                  
                                                    <input  type="file" name="foto" id="foto" class="form-control margin-bottom-20">
                                                </div>
                                             
                                            </div>
                                           
                                            <div class="clearfix"></div>
                                            <div class="row">
                                                
                                                <div class="col-md-4 col-sm-4 col-xs-12 text-right">
                                                    <button type="submit" class="btn btn-theme btn-sm">Actualizar mis datos</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    
                                    <div class="profile-edit tab-pane fade" id="settings">
                                        <h2 class="heading-md">Manage your Notifications.</h2>
                                        <p>Below are the notifications you may manage.</p>
                                        <br>
                                        <form>
                                            <div class="skin-minimal">
                                                <ul class="list">
                                                    <li>
                                                        <input type="checkbox" id="minimal-checkbox-1">
                                                        <label for="minimal-checkbox-1">Send me email notification when
                                                            Ad is processed</label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" id="minimal-checkbox-2">
                                                        <label for="minimal-checkbox-2">Send me email notification when
                                                            user comment</label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" id="minimal-checkbox-3">
                                                        <label for="minimal-checkbox-3">Send me email notification for
                                                            the latest update</label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" id="minimal-checkbox-4">
                                                        <label for="minimal-checkbox-4"> Receive our monthly
                                                            newsletter</label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" id="minimal-checkbox-5">
                                                        <label for="minimal-checkbox-5">Email notification</label>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="button-group margin-top-20">
                                                <button class="btn btn-sm btn-default" type="button">Reset</button>
                                                <button type="submit" class="btn btn-sm btn-theme">Save Changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Row End -->
                    </div>
                    <!-- Middle Content Area  End -->
                </div>
                <!-- Row End -->
            </div>
            <!-- Main Container End -->
        </section>
        <!-- =-=-=-=-=-=-= Ads Archives End =-=-=-=-=-=-= -->
        <!-- =-=-=-=-=-=-= FOOTER =-=-=-=-=-=-= -->
       <?php echo $__env->make('templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- =-=-=-=-=-=-= FOOTER END =-=-=-=-=-=-= -->
    </div>
    <!-- Main Content Area End -->
    <!-- Post Ad Sticky -->
    <a href="<?php echo e(url('/publicar-anuncio')); ?>" class="sticky-post-button hidden-xs">
        <span class="sell-icons">
            <i class="flaticon-photo"></i>
        </span>
        <h4>Publicar</h4>
    </a>
    <!-- Back To Top -->
    <a href="#0" class="cd-top">Top</a>
    <!-- Back To Top -->

    <!-- =-=-=-=-=-=-= JQUERY =-=-=-=-=-=-= -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap Core Css  -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Jquery Easing -->
    <script src="js/easing.js"></script>
    <!-- Menu Hover  -->
    <script src="js/forest-megamenu.js"></script>
    <!-- Jquery Appear Plugin -->
    <script src="js/jquery.appear.min.js"></script>
    <!-- Numbers Animation   -->
    <script src="js/jquery.countTo.js"></script>
    <!-- Jquery Smooth Scroll  -->
    <script src="js/jquery.smoothscroll.js"></script>
    <!-- Jquery Select Options  -->
    <script src="js/select2.min.js"></script>
    <!-- noUiSlider -->
    <script src="js/nouislider.all.min.js"></script>
    <!-- Carousel Slider  -->
    <script src="js/carousel.min.js"></script>
    <script src="js/slide.js"></script>
    <!-- Image Loaded  -->
    <script src="js/imagesloaded.js"></script>
    <script src="js/isotope.min.js"></script>
    <!-- CheckBoxes  -->
    <script src="js/icheck.min.js"></script>
    <!-- Jquery Migration  -->
    <script src="js/jquery-migrate.min.js"></script>
    <!-- Sticky Bar  -->
    <script src="js/theia-sticky-sidebar.js"></script>
    <!-- Style Switcher -->
    <script src="js/color-switcher.js"></script>
    <!-- Template Core JS -->
    <script src="js/custom.js"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\passionrealprod\resources\views/pages/miCuenta.blade.php ENDPATH**/ ?>