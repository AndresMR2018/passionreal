
<?php $__env->startSection('content'); ?>
<div class="container">
<form method="post" action="<?php echo e(url('/admin/credito')); ?>" enctype="multipart/form-data">
<!-- //ESTO ME APUNTA A CATEGORIA.STORE -->
<?php echo csrf_field(); ?>
<?php echo $__env->make('admin.credito.form',['modo'=>'Crear'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\passionreal\resources\views/admin/credito/create.blade.php ENDPATH**/ ?>