

<?php $__env->startSection('content'); ?>
<div class="container">




      


<table class="table table-light">
<thead class="thead-light">
<tr>
<th>#</th>
<th>Rol</th>
<th>Acciones</th>
</tr>
</thead>

    <tbody>
    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($rol->id); ?></td>
            <td><?php echo e($rol->name); ?></td>
          
            
            <td>
            <a href="" id="botoncol" class="btn btn-warning mb-2 ">Editar</a>

            <form method="post" action="" class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

                <input type="submit" value="Borrar" id="botoncol" class="btn btn-danger" onclick="return confirm('Desea borrar?')">
            </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\passionreal\resources\views/admin/role/index.blade.php ENDPATH**/ ?>