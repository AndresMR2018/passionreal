<h1><?php echo e($modo); ?> paquete</h1>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($error); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="form-group">
    <label for="Paquete">Lapso de horas entre cada activación</label>
    <input type="text" class="form-control" name="periodo_horas" id="periodo_horas"
        value="<?php echo e(isset($paquete->periodo_horas) ? $paquete->periodo_horas : old('periodo_horas')); ?>">
</div>

<input type="submit" class="btn btn-success" value="<?php echo e($modo); ?> paquete">
<a href="<?php echo e(url('admin/paquete/')); ?>" class="btn btn-primary">Regresar</a>
<?php /**PATH C:\xampp\htdocs\passionreal\resources\views/admin/paquete/form.blade.php ENDPATH**/ ?>