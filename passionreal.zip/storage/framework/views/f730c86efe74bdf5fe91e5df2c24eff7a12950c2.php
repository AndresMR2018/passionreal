<div class="colored-header">
    <!-- Top Bar -->
    <div class="header-top">
        <div class="container">
            <div class="row">
                <!-- Header Top Left -->
                <div class="header-top-left col-md-8 col-sm-6 col-xs-12 hidden-xs">
                    
                </div>
                <!-- Header Top Right Social -->
                <div class="header-right col-md-4 col-sm-6 col-xs-12 ">
                    <div class="pull-right">
                        <ul class="listnone">
                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                    <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-sign-in"></i>Iniciar sesión</a></li>
                                <?php endif; ?>
                                <?php if(Route::has('register')): ?>
                                    <li><a href="<?php echo e(route('register')); ?>"><i class="fa fa-unlock"
                                                aria-hidden="true"></i>Registrarse</a></li>
                                <?php endif; ?>
                            <?php else: ?>
                            <li style="color: white"><a href="<?php echo e(url('/creditos')); ?>"><i style="color: white" class="fas fa-coins"></i><?php echo e(Auth::user()->perfil->creditos); ?> créditos</a></li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                        aria-haspopup="true" aria-expanded="false"><i class="icon-profile-male"
                                            aria-hidden="true"></i><?php echo e(Auth::user()->name); ?><span
                                            class="caret"></span></a>
                                    <ul class="dropdown-menu">

                                        <li><a href="<?php echo e(route('cliente.miCuenta')); ?>">Mi cuenta</a></li>
                                        <?php if(Auth::check() ): ?>
                                            <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
                                        <?php endif; ?>
                                        <li><a href="<?php echo e(route('cliente.misAnuncios')); ?>">Mis anuncios</a></li>
                                        
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                            class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <li>
                                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                      document.getElementById('logout-form').submit();">
                                                <?php echo e(__('Cerrar sesión')); ?>

                                            </a>
                                        </li>

                                    </ul>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top Bar End -->
    <div class="clearfix"></div>
    <!-- Navigation Menu -->
    <nav id="menu-1" class="mega-menu">
        <!-- menu list items container -->
        <section class="menu-list-items">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <!-- menu logo -->
                        <ul class="menu-logo">
                            <li>
                                <a href="<?php echo e(route('home.inicio')); ?>"><img style="width: 100px"
                                        src="<?php echo e(asset('/images/logo/logoPassionReal.jpeg')); ?>" alt="logo"> </a>
                            </li>
                        </ul>
                        <!-- menu links -->
                        <ul class="menu-links">
                            <!-- active class -->
                            <li>
                                <a href="<?php echo e(url('/')); ?>"> Inicio <i class=" fa-indicator"></i></a>
                                
                            </li>
                            <li>
                                <a>Categorías <i
                                        class="fa fa-angle-down fa-indicator"></i></a>
                                <!-- drop down multilevel  -->
                                <ul class="drop-down-multilevel">
                                 <li><a href="<?php echo e(route('home.findAllCategorias')); ?>">Todas</a></li>
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('home.find_by_categoria', $categoria->id)); ?>"><?php echo e($categoria->nombre); ?>

                                            </a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          
                                </ul>
                            </li>
                            <?php if(auth()->guard()->guest()): ?>
                            &nbsp;
                            <?php else: ?>
                            <li><a href="<?php echo e(url('/creditos')); ?>"> Créditos <i class=" fa-indicator"></i></a></li>
                            <?php endif; ?>
                            
                            
                            
                            
                         
                        </ul>
                        <ul class="menu-search-bar">
                            <li>
                                <a href="<?php echo e(route('cliente.crearAnuncio')); ?>" class="btn btn-light"><i
                                        class="fa fa-plus" aria-hidden="true"></i> Publicar anuncio</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    </nav>
</div>
<?php /**PATH C:\xampp\htdocs\passionreal\resources\views/templates/header2.blade.php ENDPATH**/ ?>