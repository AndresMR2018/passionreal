<h1><?php echo e($modo); ?> crédito</h1>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($error); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="form-group">
    <label for="Credito"> cantidad de créditos </label>
    <input type="text" class="form-control" name="cantidad" id="cantidad"
        value="<?php echo e(isset($credito->cantidad) ? $credito->cantidad : old('cantidad')); ?>">
</div>
<div class="form-group">
    <label for="Credito"> valor por la cantidad de créditos </label>
    <input type="text" class="form-control" name="valor" id="valor"
        value="<?php echo e(isset($credito->valor) ? $credito->valor : old('valor')); ?>">
</div>
<div class="form-group">
    <label for="Credito"> Descuento % (Opcional) </label>
    <input type="text" class="form-control" name="descuento" id="descuento"
        value="<?php echo e(isset($credito->descuento) ? $credito->descuento : old('descuento')); ?>">
</div>

<input type="submit" class="btn btn-success" value="<?php echo e($modo); ?> credito">
<a href="<?php echo e(url('admin/credito/')); ?>" class="btn btn-primary">Regresar</a>
<?php /**PATH C:\xampp\htdocs\passionreal\resources\views/admin/credito/form.blade.php ENDPATH**/ ?>