

<?php $__env->startSection('content'); ?>
<div class="container">

<?php if(Session::has('mensaje')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
<?php echo e(Session::get('mensaje')); ?>

<button type="button" class="close" data-dismiss="alert" role="alert">
<span aria-button="true">&times;</span>
</button>
</div>
<?php endif; ?>

<table class="table table-light">
<thead class="thead-light">
<tr>
<th>#</th>
<th>Usuario</th>
<th>Cuenta verificada</th>
<th>Código recibido</th>
<th>Código enviado por el usuario</th>
<th>Foto</th>
<th>Acciones</th>
</tr>
</thead>

    <tbody>
    <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($s->id); ?></td>
            <td><?php echo e($s->user->name); ?></td>
            <td><?php echo e($s->user->cta_validada); ?></td>
            <td>codigo por recibir de api</td>
            <td><?php echo e($s->codigo_enviado); ?></td>
            <td>
                <img class="img-thumbnail img-fluid" width="100px" src="<?php echo e(asset('storage').'/'.$s->foto); ?>" alt=" ">
                </td>
            
            <td>
              
                   <a class="btn btn-success" href="<?php echo e(url('/admin/aprobar-cuenta/'.$s->user->id)); ?>">Cambiar estado</a>
      
           
            <form method="post" action="<?php echo e(url('admin/solicitud/'.$s->id)); ?>" class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

                <input type="submit" value="Borrar" id="botoncol" class="btn btn-danger" onclick="return confirm('Desea borrar?')">
            </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\passionreal\resources\views/admin/solicitudes/index.blade.php ENDPATH**/ ?>