<div class="app-download-section style-2">
    <!-- app-download-section-wrapper -->
    <div class="app-download-section-wrapper">
       <!-- app-download-section-container -->
       <div class="app-download-section-container">
          <!-- container -->
          <div class="container">
             <!-- row -->
             <div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12">
                   <div class="mobile-image-content"> <img src="images/hand.png" alt=""> </div>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                   <div class="app-text-section">
                      <h5>Download our app</h5>
                      <h3>Get Our App For Your Mobile</h3>
                      <ul>
                         <li>Find nearby cars in your network with Scholar</li>
                         <li>Browse real hirers reviews to know why choose Scholar</li>
                         <li>Rent a car so easy with a tap !</li>
                         <li>Rent a car so easy with a tap !</li>
                      </ul>
                      <div class="app-download-btn">
                         <div class="row">
                            <div class="col-md-6 col-sm-12 col-xs-12">
                               <!-- Windows Store -->
                               <a href="#" title="Windows Store" class="btn app-download-button">
                               <span class="app-store-btn">
                               <i class="fa fa-windows"></i>
                               <span>
                               <span>Download From</span>
                               <span>Windows Store </span>
                               </span>
                               </span>
                               </a>
                               <!-- /Windows Store -->
                            </div>
                            <div class="col-md-6 col-sm-12  col-xs-12">
                               <!-- Windows Store -->
                               <a href="#" title="Windows Store" class="btn app-download-button"> <span class="app-store-btn">
                               <i class="fa fa-apple"></i>
                               <span>
                               <span>Download From</span> <span>Apple Store </span> </span>
                               </span>
                               </a>
                               <!-- /Windows Store -->
                            </div>
                            <!-- Windows Store -->
                         </div>
                      </div>
                   </div>
                </div>
             </div>
             <!-- /row -->
          </div>
          <!-- /container -->
       </div>
       <!-- /app-download-section-container -->
    </div>
    <!-- /download-section-wrapper -->
 </div><?php /**PATH C:\xampp\htdocs\passionreal\resources\views/components/publicidad.blade.php ENDPATH**/ ?>