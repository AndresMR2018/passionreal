

<?php $__env->startSection('content'); ?>
<div class="container">

<?php if(Session::has('mensaje')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
<?php echo e(Session::get('mensaje')); ?>

<button type="button" class="close" data-dismiss="alert" role="alert">
<span aria-button="true">&times;</span>
</button>
</div>
<?php endif; ?>


      <div class="menu__datos">
<div class="botones">
<a href="<?php echo e(url('admin/categoria/create')); ?>" class="btn btn-success mb-2">Registrar nueva categoría</a>
<!-- Se manda a llamar al metodo create que trae la vista del formulario -->
</div>

</div>


<table class="table table-light">
<thead class="thead-light">
<tr>
<th>#</th>
<th>Nombre de la categoría</th>
<th>Foto</th>
<th>Acciones</th>
</tr>
</thead>

    <tbody>
    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($c->id); ?></td>
            <td><?php echo e($c->nombre); ?></td>
            <td>
                <img class="img-thumbnail img-fluid" width="100px" src="<?php echo e(asset('storage').'/'.$c->foto); ?>" alt=" ">
                </td>
            
            <td>
            <a href="<?php echo e(url('admin/categoria/'.$c->id.'/edit')); ?>" id="botoncol" class="btn btn-warning mb-2 ">Editar</a>

            <form method="post" action="<?php echo e(url('admin/categoria/'.$c->id)); ?>" class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

                <input type="submit" value="Borrar" id="botoncol" class="btn btn-danger" onclick="return confirm('Desea borrar?')">
            </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $categorias->links(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\passionreal\resources\views/admin/categoria/index.blade.php ENDPATH**/ ?>