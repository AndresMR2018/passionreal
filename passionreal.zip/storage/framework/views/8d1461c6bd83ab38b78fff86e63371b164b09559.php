

<?php $__env->startSection('content'); ?>
<div class="container">

<?php if(Session::has('mensaje')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
<?php echo e(Session::get('mensaje')); ?>

<button type="button" class="close" data-dismiss="alert" role="alert">
<span aria-button="true">&times;</span>
</button>
</div>
<?php endif; ?>


      <div class="menu__datos">
<div class="botones">
<a href="<?php echo e(url('admin/credito/create')); ?>" class="btn btn-success mb-2">Registrar nuevo crédito</a>
<!-- Se manda a llamar al metodo create que trae la vista del formulario -->
</div>

</div>


<table class="table table-light">
<thead class="thead-light">
<tr>
<th>#</th>
<th>Valor de credito</th>
<th>Cantidad de creditos</th>
<th>Descuento</th>
<th>Acciones</th>
</tr>
</thead>

    <tbody>
    <?php $__currentLoopData = $creditos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($credito->id); ?></td>
            <td><?php echo e($credito->valor); ?></td>
            <td><?php echo e($credito->cantidad); ?></td>
            <td><?php echo e($credito->descuento); ?></td>
            <td>
            <a href="<?php echo e(url('admin/credito/'.$credito->id.'/edit')); ?>" id="botoncol" class="btn btn-warning mb-2 "><i class="fas fa-edit"></i></a>

            <form method="post" action="<?php echo e(url('admin/credito/'.$credito->id)); ?>" class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

                <button type="submit" class="btn btn-danger" onclick="return confirm('Desea borrar?')"><i class="fas fa-trash-alt"></i></button>
              
            </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $creditos->links(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\passionreal\resources\views/admin/credito/index.blade.php ENDPATH**/ ?>