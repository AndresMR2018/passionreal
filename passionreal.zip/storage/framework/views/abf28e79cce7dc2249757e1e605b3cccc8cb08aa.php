
<?php $__env->startSection('content'); ?>
<div class="container">
<form method="post" enctype="multipart/form-data" action="<?php echo e(url('admin/paquete/'.$paquete->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PATCH')); ?>


<?php echo $__env->make('admin.paquete.form',['modo'=>'Editar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\passionreal\resources\views/admin/paquete/edit.blade.php ENDPATH**/ ?>