



<h1><?php echo e($modo); ?> categoría</h1>

<?php if(count($errors)>0): ?>
<div class="alert alert-danger" role="alert">
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<?php echo e($error); ?>

</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>

<div class="form-group">
<label for="Nombre">Nombre</label>
<input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e(isset($categoria->nombre)?$categoria->nombre:old('nombre')); ?>">
</div>
<div class="form-group">
    <!-- <label for="Foto">Foto</label> -->
    <?php if(isset($categoria->Foto)): ?>
    <img class="img-thumbnail img-fluid" width="100px" src="<?php echo e(asset('storage').'/'.$categoria->foto); ?>"  alt=" ">
    <?php endif; ?>
    <input type="file" name="foto" id="Foto" >
    <img id="FotoCargada" class="img-thumbnail img-fluid" style="max-width: 100px;">
    
    </div>

<input type="submit" class="btn btn-success" value="<?php echo e($modo); ?> categoria">
<a href="<?php echo e(url('admin/categoria/')); ?>" class="btn btn-primary">Regresar</a>



<?php /**PATH C:\xampp\htdocs\passionreal\resources\views/admin/categoria/form.blade.php ENDPATH**/ ?>