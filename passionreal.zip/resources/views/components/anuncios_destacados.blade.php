<div class="container">
    <!-- Row -->
    <div class="row">
       <!-- Category Grid  -->
       <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="box">
             <img alt="img" src="images/category/cars.png">
             <h4><a href="#">Cars & Bikes</a></h4>
             <strong>1,265 Jobs</strong> 
          </div>
       </div>
       <!-- Category Grid  -->
       <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="box">
             <img alt="img" src="images/category/mobile-1.png">
             <h4><a href="#">Mobile Phones</a></h4>
             <strong>1,265 Ads</strong> 
          </div>
       </div>
       <!-- Category Grid  -->
       <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="box">
             <img alt="img" src="images/category/applinces.png">
             <h4><a href="#">Home Appliances</a></h4>
             <strong>6,213 Ads</strong> 
          </div>
       </div>
       <!-- Category Grid  -->
       <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="box">
             <img alt="img" src="images/category/cloths.png">
             <h4><a href="#">Clothing</a></h4>
             <strong>3,750 Ads</strong> 
          </div>
       </div>
       <!-- Category Grid  -->
       <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="box">
             <img alt="img" src="images/category/education.png">
             <h4><a href="#">Education & Art</a></h4>
             <strong>5,913 Ads</strong> 
          </div>
       </div>
       <!-- Category Grid  -->
       <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="box">
             <img alt="img" src="images/category/computer-1.png">
             <h4><a href="#">Computer & Laptops</a></h4>
             <strong>9,942 Ads</strong> 
          </div>
       </div>
       <!-- Category Grid  -->
       <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="box">
             <img alt="img" src="images/category/pets.png">
             <h4><a href="#">Pets & Animals</a></h4>
             <strong>3,891 Ads</strong> 
          </div>
       </div>
       <!-- Category Grid  -->
       <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="box">
             <img alt="img" src="images/category/newspaper.png">
             <h4><a href="#">Newspaper Jobs</a></h4>
             <strong>7,418 Ads</strong> 
          </div>
       </div>
    </div>
    <!-- Row End -->
 </div>