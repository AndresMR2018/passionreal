<div id="banner">
    <div class="container">
       <div class="search-container">
          <!-- Form -->
          <h2>Qué estás buscando ?</h2>
          <form>
             <!-- Search Input -->
             <div class="col-md-4 col-sm-6 col-xs-12 no-padding">
                <div class="form-group">
                   <input type="text" class="form-control banner-icon-search" name="keyword" placeholder="buscar por nombre del anuncio" value=""> 
                </div>
             </div>
             <!-- Search Category -->
             <div class="col-md-3 col-sm-6 col-xs-12 no-padding">
                <div class="form-group">
                   <select class="category form-control" >
                      <option label="Seleccione una ciudad"></option>
                      <option value="0">Quito</option>
                      <option value="0">Sto.Domingo</option>
                     
                   </select>
                </div>
             </div>
             <!-- Search Location -->
             <div class="col-md-3 col-sm-9 col-xs-12 no-padding">
                <div class="form-group">
                   <select class="cities form-control">
                      <option value="0">Mujeres</option>
                      <option value="1">Hombres</option>
                      
                   </select>
                </div>
             </div>
             <div class="col-md-2 col-sm-3 col-xs-12 no-padding">
                <div class="form-group form-action">
                   <button type="button" class="btn btn-theme btn-search-submit">Buscar</button>
                </div>
             </div>
          </form>
       </div>
    </div>
 </div>